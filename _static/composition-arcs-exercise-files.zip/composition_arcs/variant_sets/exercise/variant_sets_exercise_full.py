# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from pathlib import Path

from pxr import Usd, UsdLux, UsdShade, Sdf


def toggle_lights(on: bool):
    if on:
        intensity = 100.0
        emissive_color = (1.0, 1.0, 1.0)
    else:
        intensity = 0.0
        emissive_color = (0.0, 0.0, 0.0)
    
    lights_scope = stage.GetPrimAtPath("/World/Lights")
    for prim in Usd.PrimRange(lights_scope):
        if prim.HasAPI(UsdLux.LightAPI):
            light_api = UsdLux.LightAPI(prim)
            light_api.GetIntensityAttr().Set(intensity)
    
    prim = stage.GetPrimAtPath("/World/Looks/light/light")
    shader = UsdShade.Shader(prim)
    shader.CreateInput("emissiveColor", Sdf.ValueTypeNames.Color3f).Set(emissive_color)



working_dir = Path(__file__).parent
stage = Usd.Stage.Open(str(working_dir / "street_lamp_dbl.usd"))


root = stage.GetDefaultPrim()
vset: Usd.VariantSet = root.GetVariantSets().AddVariantSet("lights")
vset.AddVariant("on")
vset.AddVariant("off")
vset.SetVariantSelection("on")
with vset.GetVariantEditContext():
    toggle_lights(True)
    
vset.SetVariantSelection("off")
with vset.GetVariantEditContext():
    toggle_lights(False)

# Make sure you select the variant you intend to select for this layer.
# Alternatively, you can use Usd.VariantSet.ClearVariantSelection()
# if you would prefer to not make a selection in the current EditTarget.
vset.SetVariantSelection("off")

stage.GetRootLayer().Export(str(working_dir / "street_lamp_dbl_vset.usda"))

